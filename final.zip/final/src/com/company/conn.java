package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

public interface conn {
    public boolean active = true;
    abstract public String getResp();
    abstract public void caccept() throws IOException;
    abstract public void connclose() throws IOException;
}
